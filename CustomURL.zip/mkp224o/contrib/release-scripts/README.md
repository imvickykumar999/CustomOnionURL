packages that work on archlinux:
wine-wow64 mingw-w64-toolchain mingw-w64-ldd mingw-w64-pcre2 mingw-w64-libsodium zip zopfli
