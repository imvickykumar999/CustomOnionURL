# Usage

## Building Image Locally
`docker build -f contrib/docker/Dockerfile -t mkp224o .`

## Running Image Locally
`docker run -it -v $(pwd):/root/data mkp224o neko`
