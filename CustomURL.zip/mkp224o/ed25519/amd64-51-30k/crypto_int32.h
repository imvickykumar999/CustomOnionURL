#include <stdint.h>
#define crypto_int32 int32_t
